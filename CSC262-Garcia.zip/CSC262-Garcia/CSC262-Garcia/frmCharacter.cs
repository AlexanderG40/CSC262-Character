namespace CSC262_Garcia
{
    public partial class frmCharacter : Form
    {
        public frmCharacter()
        {
            InitializeComponent();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            Character character = new Character(12, "Jesse", 28, 100, 50);

        }
    }
}
