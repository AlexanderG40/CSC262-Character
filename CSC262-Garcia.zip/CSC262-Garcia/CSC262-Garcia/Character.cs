﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSC262_Garcia
{
    public class Character
    {
        // our private fields/attributes
        private int attack;
        private string name;
        private int age;
        private int health;
        private int defense;

        // public properties 
        public int Attack
        {
            get { return attack; }
            set { attack = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int Age
        {
            get { return age; }
            set { age = value; }
        }
        
        public int Health
        {
            get { return health; }
            set { health = value; }
        }
        public int Defense
        {
            get { return defense; } 
            set { defense = value; }
        }

        // set the constructor = pass in each attribute if that makes sense for the program
        public Character(int attack, string name, int age, int health, int defense)
        {
            Attack = attack;
            Name = name;
            Age = age;
            Health = health;
            Defense = defense;
        }
    }
}
